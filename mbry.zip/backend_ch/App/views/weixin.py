# from ..extensions import db
from flask import Blueprint, jsonify, request
import hashlib


weixin = Blueprint("weixin", __name__)

@weixin.route("/weixin")
def weiXin():
    signature = request.args.get("signature")
    timestamp = request.args.get("timestamp")
    nonce = request.args.get("nonce")
    echostr = request.args.get("echostr")
    token = "sxy122333"  # 请按照公众平台官网\基本配置中信息填写

    list = [token, timestamp, nonce]
    sha1 = hashlib.sha1()
    map(sha1.update, list)
    hashcode = sha1.hexdigest()
    if hashcode == signature:
        print(echostr)
        return echostr
    else:
        return "5"
