from ..extensions import db
from flask import Blueprint, jsonify, request


car = Blueprint("car", __name__)

# 购物车列表
@car.route("/list",methods=["POST",])
def car_list():
    name = request.form.get("name")
    data = db.session.execute(f'select * from car where uname = "{name}"')
    lis = []
    for i in data:
        dic ={}
        for k,v in i.items():
            dic[k] = v
        lis.append(dic)
    return jsonify(lis)


# 购物车添加
@car.route("/add",methods=["POST",])
def car_add():
    name = '"'+ request.form.get("name")+'"'
    gid = request.form.get("gid")
    num = request.form.get("num")
    spec = request.form.get("spec")
    db.session.execute(f'INSERT INTO car (uname,gid,num,spec) '
                       f'VALUES ({name},{gid},{num},{spec})')

    db.session.commit()

    return "ok"


# 购物车删除
@car.route("/del",methods=["POST",])
def car_del():
    id = int(request.form.get("id"))
    num = int(request.form.get("num"))
    if num:
        db.session.execute(f'UPDATE car SET num = {num} WHERE id = {id}')
    else:
        db.session.execute(f'DELETE FROM car WHERE id={id}')

    db.session.commit()

    return "ok"